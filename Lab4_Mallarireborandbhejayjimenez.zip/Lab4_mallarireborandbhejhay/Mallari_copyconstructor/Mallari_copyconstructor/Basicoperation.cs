﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mallari_copyconstructor
{
    public class Basicoperation
    {
        public double num1;
        public double num2;
        public Basicoperation()
        {


        }

        public Basicoperation(double Bopc)
        {

        }


        public Basicoperation(Basicoperation Bopc) // copy constructor hahah madali basta iintindihin 
        {

        }
    }
}
