﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mallari_copyconstructor
{
    class Program
    {
        static void Main(string[] args)
        {

            string partner =   "*****Rebor Malari and Bejhay Jimenez********";
            string prof =       "******Ma'am Cherry Collera******";
            Basicoperation Bopc =new Basicoperation();
           
            Basicoperation Bopc1 = new Basicoperation(Bopc); //copy constructor heheh nakuha din kita 
            
            Console.Write("Enter 1st Number:  ");
            Bopc.num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter 2nd Number:  ");
            Bopc.num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Sum:  {0}", Bopc.num1 + Bopc.num2);
            Console.ReadLine();

            Console.Write("Product:  {0}", Bopc.num1 * Bopc.num2);
            Console.ReadLine();

            Console.Write("Qoutient:  {0}", Bopc.num1 / Bopc.num2);
            Console.ReadLine();

            Console.Write("Subtraction:  {0}", Bopc.num1 - Bopc.num2);
            Console.ReadLine();

            Console.WriteLine("PARTNER:" + partner + "");
            Console.ReadLine();
            Console.WriteLine("PROFESSOR:" + prof + "");
            Console.ReadLine();
            Console.WriteLine(      "-----------------BSIT-NW4B--------------"    );

            Console.ReadKey();

        }
    }
}
